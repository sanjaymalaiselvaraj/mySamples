package MercuryTour;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class sample1 {
	public static void main(String[] args) {
		 
		System.setProperty("webdriver.chrome.driver", "D:\\New folder\\MSPerfectAutomationTest\\src\\MercuryTour\\chromedriver.exe");
		 
		// Initialize browser
		WebDriver driver=new ChromeDriver();
		 
		// Open facebook
		driver.get("http://newtours.demoaut.com/");
		 
		
		
		// Maximize browser
		 
		driver.manage().window().maximize();
		 
		}
}
